Hello! I am Siddhant; 24 years old, third year Btech CSE student.

I'm currently working with,

-   React (TS)
-   NodeJS
-   Flask (Python)
-   HTML/SCSS
-   WebSockets
-   GraphQL
